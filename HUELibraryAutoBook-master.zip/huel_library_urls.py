"""
来选座系统所使用的url地址
"""

# 首页
index_url = 'http://wechat.laixuanzuo.com/index.php/reserve/index.html?f=wechat'

# 明日预定      https://wechat.laixuanzuo.com/index.php/reserve/layoutApi/action=prereserve_event&libid=10065
#https://wechat.laixuanzuo.com/index.php/prereserve/save/libid=10065&sTKmM3nQBnQEx=7,14&yzm=2191
booking_url = 'http://wechat.laixuanzuo.com/index.php/prereserve/index.html'

# 预定
booked_url = "https://wechat.laixuanzuo.com/index.php/reserve/get/libid=10501&"
